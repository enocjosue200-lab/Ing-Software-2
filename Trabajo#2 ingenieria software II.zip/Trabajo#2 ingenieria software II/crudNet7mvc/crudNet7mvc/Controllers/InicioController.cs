using crudNet7mvc.Datos;
using crudNet7mvc.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace crudNet7mvc.Controllers
{
    public class InicioController : Controller
    {
        private AplicacionDbContext _contexto;

        public InicioController(AplicacionDbContext contexto)
        {
            _contexto=contexto;
         
        }
        [HttpGet]

        public async Task<IActionResult> Index()
        {
            return View(await _contexto.contactos.ToListAsync());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
