﻿using crudNet7mvc.Models;
using Microsoft.EntityFrameworkCore;

namespace crudNet7mvc.Datos
{
    public class AplicacionDbContext : DbContext
    {
        public AplicacionDbContext(DbContextOptions<AplicacionDbContext>options) : base(options)
        {

        }
        //AGREGAR LOS MODELOS AQUI
        public DbSet<Contacto> contactos { get; set; }

    }
}
